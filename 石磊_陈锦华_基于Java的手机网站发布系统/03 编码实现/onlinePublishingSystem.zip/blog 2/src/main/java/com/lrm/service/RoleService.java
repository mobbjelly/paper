package com.lrm.service;

import com.lrm.po.Role;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

/**
 * Created by limi on 2017/10/15.
 */
public interface RoleService {

    Role saveRole(Role role);

    Role getRole(Long id);

    Role getRoleByName(String name);

    Page<Role> listRole(Pageable pageable);

    List<Role> listRole();

    Role updateRole(Long id, Role role);

    void deleteRole(Long id);
}
