package com.lrm.service;

import com.lrm.NotFoundException;
import com.lrm.dao.RoleRepository;
import com.lrm.po.Role;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class RoleServiceImpl implements RoleService {
    @Autowired
    private RoleRepository roleRepository;

    @Transactional
    @Override
    public Role saveRole(Role role) {
        return roleRepository.save(role);
    }

    @Transactional
    @Override
    public Role getRole(Long id) {
        return roleRepository.findOne(id);
    }

    @Override
    public Role getRoleByName(String name) {
        return roleRepository.findByName(name);
    }

    @Transactional
    @Override
    public Page<Role> listRole(Pageable pageable) {
        return roleRepository.findAll(pageable);
    }

    @Override
    public List<Role> listRole() {
        return roleRepository.findAll();
    }

    @Transactional
    @Override
    public Role updateRole(Long id, Role role) {
        Role t = roleRepository.findOne(id);
        if (t == null) {
            throw new NotFoundException("不存在该类型");
        }
        BeanUtils.copyProperties(role,t);
        return roleRepository.save(t);
    }



    @Transactional
    @Override
    public void deleteRole(Long id) {
        roleRepository.delete(id);
    }
}
